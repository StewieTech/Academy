package gross_calculator;

public class GrossPayCalculator {

    public static void main(String[] args){
        System.out.println("Hello World");
    }
}
